# James Docker-Driven Blog

An example Jekyll blog for use with the Jekyll service in [The Docker Book](http://www.dockerbook.com).

## Source

Adapted from [this template](https://github.com/dbtek/jekyll-bootstrap-3.git).

## License

MIT

