#ifndef TREE_H
#define TREE_H
typedef struct node
{
    int data;
    struct node *lchild;
    struct node *rchild;
}node, *BiTree;
#endif
