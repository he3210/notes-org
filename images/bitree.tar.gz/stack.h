#include "tree.h"
#define N 1024
#define elem_type BiTree
typedef struct
{
    elem_type data[N];
    int top;
}stack;

void init_stack(stack &s)
{
    s.top = -1;
}

bool is_empty(stack &s)
{
    if(s.top == -1)
        return true;
    else
        return false;
}

bool push(stack &s, elem_type &x)
{
    if(s.top == N-1)
        return false;
    s.data[++s.top] = x;
    return true;
}

bool pop(stack &s, elem_type &x)
{
    if(s.top == -1)
        return false;
    x = s.data[s.top--];
    return true;
}

bool get_top(stack &s, elem_type &x)
{
    if(s.top == -1)
        return false;
    x = s.data[s.top];
    return true;
}

int stack_length(stack &s)
{
    return s.top+1;
}
