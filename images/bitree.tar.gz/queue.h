#include "tree.h"
#define N 1024
#define elem_type BiTree

typedef struct queue
{
    elem_type data[N];
    int front, rear;
}queue;

void init_queue(queue &q)
{
    q.rear = q.front = 0;
}

bool is_empty(queue &q)
{
    if(q.rear == q.front)
        return true;
    else
        return false;
}

bool enqueue(queue &q, elem_type &x)
{
    if((q.rear+1) % N == q.front)
        return false;
    q.data[q.rear] = x;
    q.rear = (q.rear+1) % N;
    return true;
}

bool dequeue(queue &q, elem_type &x)
{
    if(q.rear == q.front)
        return false;
    x = q.data[q.front];
    q.front = (q.front+1) % N;
    return true;
}

int queue_length(queue &q)
{
    return (N+q.rear-q.front)%N;
}
